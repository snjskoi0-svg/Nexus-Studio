plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.nexus.studio"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nexus.studio"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.1.2"
    }
}
