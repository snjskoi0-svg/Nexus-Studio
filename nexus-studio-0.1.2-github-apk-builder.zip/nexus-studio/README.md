# Nexus Studio 0.1

Base inicial do editor de vídeo Android + Web com motor de timeline compartilhado em TypeScript.

## Requisitos
- Node.js 20 ou superior
- npm 10 ou superior
- Android Studio (para a etapa nativa Android; a casca nativa será adicionada numa etapa posterior)

## Executar a versão Web
Na raiz do projeto:

```bash
npm install
npm run dev
```

Abra a URL local mostrada pelo Vite. Para testar no celular na mesma rede Wi-Fi, use o endereço de rede informado pelo Vite; permita conexões locais no firewall.

## Build e testes
```bash
npm test
npm run build
```

## Funcionalidades já implementadas
- Timeline com trilhas de vídeo, áudio e texto
- Seleção de clipes
- Arrastar clipes entre trilhas compatíveis
- Snap em intervalos de 250 ms
- Divisão no cursor (`S`)
- Trim das extremidades do clipe
- Exclusão (`Delete` / `Backspace`)
- Zoom da timeline
- Play/pause e scrubbing básico
- Histórico undo/redo (`Ctrl+Z`, `Ctrl+Shift+Z`)
- Inclusão de clipes placeholder
- Layout responsivo com controles para celular

## Limitações honestas da versão 0.1
- A importação cria um clipe placeholder de 5 segundos; ainda não decodifica a mídia nem mostra o vídeo/áudio importado no preview.
- O botão de reprodução movimenta o cursor; sincronização com áudio/vídeo real ainda não está conectada.
- Separação por IA ainda não está integrada a um modelo; a interface só prepara o fluxo.
- Exportação MP4, filtros e keyframes ainda não estão implementados.
- O cliente Android nativo e a ponte de execução do motor TypeScript ainda precisam ser construídos. Esta versão valida primeiro o motor e a UX compartilhados na Web.
- O undo/redo está implementado para operações do editor, mas movimentos de trim por pointer ainda geram snapshots durante o arrasto; isso será consolidado em uma única operação na próxima etapa.

## Próximas etapas
1. Persistência do projeto e histórico transacional.
2. Importação real com metadados e preview de mídia.
3. Casca Android em Kotlin/Compose e ponte para o motor compartilhado.
4. Worker de separação musical (ex. Demucs) e modelo específico para diálogo/ruído.
5. Exportação com WebCodecs/FFmpeg.wasm no navegador e Media3/MediaCodec no Android.


## Android host (starter)
A minimal Kotlin Android WebView host is in `apps/android`. It loads the same compiled web app, so the TypeScript timeline engine is shared. After running `npm run build`, copy the contents of `apps/web/dist/` into `apps/android/app/src/main/assets/` (create the `assets` directory first), then open `apps/android` in Android Studio and run the `app` configuration on a device/emulator. This is a starter wrapper, not yet a native Compose editor. Native media codecs and Android audio-separation inference will be integrated behind platform adapters in later stages.


## Atualização 0.1.1: imagens e cores
- Importação de imagens com pré-visualização local via URL de objeto.
- Templates rápidos de preview: Neon, Branco, Preto e Pôr do sol.
- Seletor de cor personalizada para o fundo.
- WebView Android com seletor de arquivos para imagens, vídeos e áudio.
- Importação ainda não adiciona a imagem como mídia persistente nem faz render/export real; o preview é local à sessão.

## Gerar o APK pela nuvem do GitHub (sem instalar Android Studio)

Este projeto inclui um workflow do GitHub Actions. Ele compila a interface, embute os recursos web no aplicativo Android e produz um **APK de teste (debug)**. O APK não é assinado para publicação na Play Store.

### Caminho mais fácil pelo celular

1. Baixe o arquivo `nexus-studio-0.1.2-github-apk-builder.zip` e, no [GitHub](https://github.com/new), crie um repositório novo chamado `nexus-studio`. Para simplificar, pode deixá-lo privado.
2. No repositório, toque em **Add file → Upload files** e envie o ZIP inteiro como um arquivo. Faça o commit.
3. Toque em **Add file → Create new file**. No campo de nome, digite exatamente `.github/workflows/build-android.yml`.
4. Abra o arquivo `nexus-studio-build-from-zip.yml` fornecido junto com este projeto, copie todo o conteúdo e cole no editor do GitHub. Faça o commit.
5. Abra a aba **Actions**. Escolha **Build Nexus Studio APK from ZIP**; se não começar automaticamente, toque em **Run workflow**.
6. Quando aparecer o visto verde, abra a execução e procure **Artifacts → nexus-studio-debug-apk**. Baixe o ZIP do artefato, extraia-o e encontre `app-debug.apk`. Abra esse APK no Android e permita instalar por essa fonte, se for solicitado.

O workflow instala Java, Android SDK e Gradle no computador virtual do GitHub; isso evita precisar instalar essas ferramentas no telefone. Ele pode levar alguns minutos e, se falhar, o log da etapa vermelha mostrará o motivo. Não compartilhe senhas ou tokens do GitHub.

### Caminho alternativo se você já extraiu o projeto

Envie os arquivos e pastas extraídos para a raiz do repositório, incluindo `.github/workflows/build-android.yml`. A compilação começará ao fazer push para `main` ou `master`, ou pode ser iniciada manualmente em **Actions**.

### Limitações funcionais da versão atual

O APK empacota o protótipo existente: timeline de demonstração, templates Neon/Branco/Preto/Pôr do sol, seleção de cor e importador de imagens, vídeos e áudio. A importação ainda é parcial: imagens podem aparecer no preview, mas reprodução/sincronização real de vídeo/áudio, exportação MP4 e separação por IA não estão implementadas.
