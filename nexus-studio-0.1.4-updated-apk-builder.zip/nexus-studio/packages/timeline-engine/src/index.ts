export type TrackKind = "video" | "audio" | "text" | "effect";

export interface Clip {
  id: string;
  name: string;
  kind: TrackKind;
  start: number;      // timeline position, milliseconds
  duration: number;   // milliseconds
  sourceOffset: number;
  color: string;
}

export interface Track {
  id: string;
  name: string;
  kind: TrackKind;
  clips: Clip[];
  muted?: boolean;
  locked?: boolean;
}

export interface TimelineProject {
  id: string;
  name: string;
  duration: number;
  tracks: Track[];
}

export const SNAP_MS = 250;
export const MIN_CLIP_MS = 250;

export function cloneProject(project: TimelineProject): TimelineProject {
  return structuredClone(project);
}

export function snapTime(time: number, enabled = true, interval = SNAP_MS): number {
  if (!enabled) return Math.max(0, Math.round(time));
  return Math.max(0, Math.round(time / interval) * interval);
}

export function moveClip(project: TimelineProject, clipId: string, trackId: string, start: number, snap = true): TimelineProject {
  const next = cloneProject(project);
  const sourceTrack = next.tracks.find(t => t.clips.some(c => c.id === clipId));
  const targetTrack = next.tracks.find(t => t.id === trackId);
  if (!sourceTrack || !targetTrack || targetTrack.locked) return project;
  const index = sourceTrack.clips.findIndex(c => c.id === clipId);
  const [clip] = sourceTrack.clips.splice(index, 1);
  clip.start = snapTime(start, snap);
  // Preserve media category compatibility: audio clips can be moved to audio tracks, etc.
  if (clip.kind !== targetTrack.kind && !(clip.kind === "video" && targetTrack.kind === "text")) {
    sourceTrack.clips.splice(index, 0, clip);
    return project;
  }
  targetTrack.clips.push(clip);
  targetTrack.clips.sort((a, b) => a.start - b.start);
  next.duration = Math.max(0, ...next.tracks.flatMap(t => t.clips.map(c => c.start + c.duration)));
  return next;
}

export function splitClip(project: TimelineProject, clipId: string, at: number): TimelineProject {
  const next = cloneProject(project);
  for (const track of next.tracks) {
    const index = track.clips.findIndex(c => c.id === clipId);
    if (index < 0) continue;
    const clip = track.clips[index];
    const local = at - clip.start;
    if (local < MIN_CLIP_MS || local > clip.duration - MIN_CLIP_MS) return project;
    const right: Clip = {
      ...clip,
      id: `${clip.id}-split-${Math.round(at)}-${Math.random().toString(36).slice(2, 7)}`,
      name: `${clip.name} (parte 2)`,
      start: at,
      duration: clip.duration - local,
      sourceOffset: clip.sourceOffset + local
    };
    clip.duration = local;
    track.clips.splice(index + 1, 0, right);
    next.duration = Math.max(0, ...next.tracks.flatMap(t => t.clips.map(c => c.start + c.duration)));
    return next;
  }
  return project;
}

export function trimClip(project: TimelineProject, clipId: string, edge: "start" | "end", time: number): TimelineProject {
  const next = cloneProject(project);
  for (const track of next.tracks) {
    const clip = track.clips.find(c => c.id === clipId);
    if (!clip || track.locked) continue;
    if (edge === "start") {
      const end = clip.start + clip.duration;
      const newStart = Math.min(end - MIN_CLIP_MS, snapTime(time));
      const delta = newStart - clip.start;
      clip.start = Math.max(0, newStart);
      clip.sourceOffset += Math.max(0, delta);
      clip.duration = end - clip.start;
    } else {
      const end = snapTime(time);
      clip.duration = Math.max(MIN_CLIP_MS, end - clip.start);
    }
    next.duration = Math.max(0, ...next.tracks.flatMap(t => t.clips.map(c => c.start + c.duration)));
    return next;
  }
  return project;
}

export function deleteClip(project: TimelineProject, clipId: string): TimelineProject {
  const next = cloneProject(project);
  for (const track of next.tracks) track.clips = track.clips.filter(c => c.id !== clipId);
  next.duration = Math.max(0, ...next.tracks.flatMap(t => t.clips.map(c => c.start + c.duration)));
  return next;
}
