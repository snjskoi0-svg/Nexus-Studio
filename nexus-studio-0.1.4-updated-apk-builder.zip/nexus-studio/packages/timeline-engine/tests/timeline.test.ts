import { describe, expect, it } from "vitest";
import { splitClip, snapTime, type TimelineProject } from "../src/index";

const project: TimelineProject = {
  id: "p", name: "Test", duration: 8000,
  tracks: [{ id: "v1", name: "Vídeo 1", kind: "video", clips: [
    { id: "c1", name: "Clipe", kind: "video", start: 0, duration: 8000, sourceOffset: 0, color: "#6d5dfc" }
  ] }]
};

describe("timeline engine", () => {
  it("snaps to nearest 250ms", () => {
    expect(snapTime(620)).toBe(500);
    expect(snapTime(640)).toBe(750);
    expect(snapTime(620, false)).toBe(620);
  });
  it("splits clip and preserves total duration", () => {
    const result = splitClip(project, "c1", 3000);
    expect(result.tracks[0].clips).toHaveLength(2);
    expect(result.tracks[0].clips[0].duration + result.tracks[0].clips[1].duration).toBe(8000);
    expect(result.tracks[0].clips[1].sourceOffset).toBe(3000);
  });
  it("does not split too close to an edge", () => {
    expect(splitClip(project, "c1", 100)).toBe(project);
  });
});
