import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Relative asset paths are required because Android loads the built app from
// file:///android_asset/index.html instead of an HTTPS origin.
export default defineConfig({
  base: "./",
  plugins: [react()],
});
