import { create } from "zustand";
import {
  deleteClip, moveClip, splitClip, trimClip, type TimelineProject, type Clip
} from "@nexus/timeline-engine";

const initial: TimelineProject = {
  id: "project-demo",
  name: "Meu primeiro projeto",
  duration: 18000,
  tracks: [
    { id: "video-1", name: "Vídeo 1", kind: "video", clips: [
      { id: "clip-video-1", name: "Cena principal", kind: "video", start: 0, duration: 8000, sourceOffset: 0, color: "#6658e8" },
      { id: "clip-video-2", name: "Cena 2", kind: "video", start: 8500, duration: 5500, sourceOffset: 0, color: "#8b5cf6" }
    ]},
    { id: "audio-1", name: "Áudio 1", kind: "audio", clips: [
      { id: "clip-audio-1", name: "Música de fundo", kind: "audio", start: 0, duration: 14000, sourceOffset: 0, color: "#159c80" }
    ]},
    { id: "text-1", name: "Texto", kind: "text", clips: [
      { id: "clip-text-1", name: "Título", kind: "text", start: 2000, duration: 4000, sourceOffset: 0, color: "#d97706" }
    ]}
  ]
};

interface State {
  project: TimelineProject;
  selectedId: string | null;
  playhead: number;
  pixelsPerSecond: number;
  playing: boolean;
  past: TimelineProject[];
  future: TimelineProject[];
  setProject: (p: TimelineProject) => void;
  select: (id: string | null) => void;
  setPlayhead: (n: number) => void;
  setZoom: (n: number) => void;
  togglePlay: () => void;
  splitSelected: () => void;
  removeSelected: () => void;
  move: (id: string, trackId: string, start: number) => void;
  trim: (id: string, edge: "start" | "end", time: number) => void;
  addClip: (kind: Clip["kind"], name: string, duration?: number) => void;
  undo: () => void;
  redo: () => void;
}
export const useEditor = create<State>((set, get) => ({
  project: initial, selectedId: "clip-video-1", playhead: 0, pixelsPerSecond: 60, playing: false, past: [], future: [],
  setProject: (project) => set(s => ({ project, past: [...s.past, s.project], future: [] })),
  select: selectedId => set({ selectedId }),
  setPlayhead: playhead => set({ playhead: Math.max(0, playhead) }),
  setZoom: pixelsPerSecond => set({ pixelsPerSecond }),
  togglePlay: () => set(s => ({ playing: !s.playing })),
  splitSelected: () => {
    const s = get(); if (!s.selectedId) return;
    const next = splitClip(s.project, s.selectedId, s.playhead);
    if (next === s.project) return;
    set({ project: next, past: [...s.past, s.project], future: [] });
  },
  removeSelected: () => {
    const s = get(); if (!s.selectedId) return;
    set({ project: deleteClip(s.project, s.selectedId), selectedId: null, past: [...s.past, s.project], future: [] });
  },
  move: (id, trackId, start) => {
    const s = get(); const next = moveClip(s.project, id, trackId, start);
    if (next !== s.project) set({ project: next, past: [...s.past, s.project], future: [] });
  },
  trim: (id, edge, time) => {
    const s = get(); const next = trimClip(s.project, id, edge, time);
    if (next !== s.project) set({ project: next, past: [...s.past, s.project], future: [] });
  },
  addClip: (kind, name, duration = 5000) => {
    const s = get();
    let track = s.project.tracks.find(t => t.kind === kind);
    let tracks = structuredClone(s.project.tracks);
    if (!track) {
      track = { id: `${kind}-${Date.now()}`, name: kind === "effect" ? "Efeitos" : kind, kind, clips: [] };
      tracks.push(track);
    }
    const target = tracks.find(t => t.id === track!.id)!;
    const clip: Clip = { id: `clip-${Date.now()}`, name, kind, start: s.playhead, duration, sourceOffset: 0,
      color: kind === "audio" ? "#159c80" : kind === "text" ? "#d97706" : kind === "effect" ? "#d946ef" : "#6658e8" };
    target.clips.push(clip);
    const project = { ...s.project, tracks, duration: Math.max(s.project.duration, clip.start + clip.duration) };
    set({ project, selectedId: clip.id, past: [...s.past, s.project], future: [] });
  },
  undo: () => set(s => {
    if (!s.past.length) return s;
    const previous = s.past[s.past.length - 1];
    return { project: previous, past: s.past.slice(0, -1), future: [s.project, ...s.future] };
  }),
  redo: () => set(s => {
    if (!s.future.length) return s;
    return { project: s.future[0], past: [...s.past, s.project], future: s.future.slice(1) };
  })
}));
