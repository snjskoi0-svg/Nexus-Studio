import React, { useEffect, useRef, useState } from "react";
import { AudioLines, ChevronDown, Clapperboard, Download, FileAudio, FileImage, FileVideo, Film, FolderOpen, Layers, Pause, Play, Plus, Scissors, Settings2, Trash2, Undo2, Redo2, ZoomIn, ZoomOut, Music2, Mic2, Sparkles } from "lucide-react";
import { useEditor } from "./store";
import type { Clip, Track } from "@nexus/timeline-engine";

const fmt = (ms: number) => `${Math.floor(ms / 60000)}:${String(Math.floor(ms / 1000) % 60).padStart(2, "0")}.${String(Math.floor(ms % 1000 / 100)).padStart(1, "0")}`;
const kindLabel = (kind: string) => ({ video: "Vídeo", audio: "Áudio", text: "Texto", effect: "Efeitos" } as Record<string,string>)[kind] || kind;

export default function App() {
  const { project, selectedId, playhead, pixelsPerSecond, playing, select, setPlayhead, setZoom, togglePlay, splitSelected, removeSelected, move, trim, addClip, undo, redo, past, future } = useEditor();
  const [activeTab, setActiveTab] = useState("timeline");
  const [importMessage, setImportMessage] = useState("Importe mídia para começar");
  const [isSeparating, setIsSeparating] = useState(false);
  const [sepMode, setSepMode] = useState("music");
  const [dragClip, setDragClip] = useState<string | null>(null);
  const [previewAssetUrl, setPreviewAssetUrl] = useState<string | null>(null);
  const [canvasColor, setCanvasColor] = useState("#25213f");
  const [templateName, setTemplateName] = useState("Neon");
  const fileRef = useRef<HTMLInputElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const selected = project.tracks.flatMap(t => t.clips).find(c => c.id === selectedId);
  const px = pixelsPerSecond / 1000;
  const totalWidth = Math.max(900, project.duration * px + 160);
  const currentTrack = project.tracks.find(t => t.clips.some(c => c.id === selectedId));
  const currentTime = fmt(playhead);

  useEffect(() => {
    if (!playing) return;
    const id = window.setInterval(() => {
      const next = playhead + 100;
      setPlayhead(next >= project.duration ? 0 : next);
    }, 100);
    return () => window.clearInterval(id);
  }, [playing, playhead, project.duration, setPlayhead]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (["INPUT", "TEXTAREA", "SELECT"].includes(target?.tagName)) return;
      if (e.code === "Space") { e.preventDefault(); togglePlay(); }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") { e.preventDefault(); e.shiftKey ? redo() : undo(); }
      if (e.key === "Delete" || e.key === "Backspace") removeSelected();
      if (e.key.toLowerCase() === "s") splitSelected();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [togglePlay, redo, undo, removeSelected, splitSelected]);

  const onImport = (files: FileList | null) => {
    if (!files?.length) return;
    const file = files[0];
    const isImage = file.type.startsWith("image/");
    const type = file.type.startsWith("video/") ? "video" : file.type.startsWith("audio/") ? "audio" : isImage ? "video" : null;
    if (!type) { setImportMessage("Formato não reconhecido"); return; }
    if (previewAssetUrl) URL.revokeObjectURL(previewAssetUrl);
    const url = URL.createObjectURL(file);
    if (isImage || file.type.startsWith("video/")) setPreviewAssetUrl(url);
    const duration = isImage ? 5000 : 5000;
    addClip(type, file.name, duration);
    setImportMessage(isImage
      ? `${file.name} importada e exibida no preview. O clipe de imagem fica com 5s iniciais.`
      : `${file.name} adicionada à timeline. Sincronização completa do arquivo ainda está em desenvolvimento.`);
  };

  const applyTemplate = (name: string, color: string) => {
    setTemplateName(name);
    setCanvasColor(color);
    setPreviewAssetUrl(null);
    setImportMessage(`Template "${name}" aplicado ao preview.`);
  };

  const timelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left + timelineRef.current.scrollLeft - 145;
    setPlayhead(Math.max(0, x / px));
  };

  const beginTrim = (e: React.PointerEvent, clip: Clip, edge: "start" | "end") => {
    e.stopPropagation(); e.preventDefault();
    const startX = e.clientX;
    const original = edge === "start" ? clip.start : clip.start + clip.duration;
    const onMove = (ev: PointerEvent) => trim(clip.id, edge, original + (ev.clientX - startX) / px);
    const onUp = () => { window.removeEventListener("pointermove", onMove); window.removeEventListener("pointerup", onUp); };
    window.addEventListener("pointermove", onMove); window.addEventListener("pointerup", onUp);
  };

  const importButton = () => fileRef.current?.click();
  const simulateSeparation = () => {
    setIsSeparating(true);
    window.setTimeout(() => {
      setIsSeparating(false);
      setImportMessage("Módulo de IA preparado na arquitetura; modelo de separação ainda precisa ser instalado e integrado.");
    }, 900);
  };

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><Clapperboard size={21}/></div><div><strong>NEXUS <span>STUDIO</span></strong><small>EDITOR DE VÍDEO • 0.1</small></div></div>
      <div className="project-name"><span className="status-dot"/> {project.name} <ChevronDown size={14}/></div>
      <div className="top-actions">
        <button className="icon-btn" title="Desfazer (Ctrl+Z)" onClick={undo} disabled={!past.length}><Undo2 size={17}/></button>
        <button className="icon-btn" title="Refazer (Ctrl+Shift+Z)" onClick={redo} disabled={!future.length}><Redo2 size={17}/></button>
        <button className="export-btn" onClick={() => setImportMessage("Exportação MP4 será conectada ao pipeline de renderização na próxima etapa.")}><Download size={16}/> Exportar</button>
      </div>
    </header>

    <main className="workspace">
      <aside className="left-panel">
        <div className="panel-heading"><span>MÍDIA E FERRAMENTAS</span><Settings2 size={15}/></div>
        <nav className="tool-nav">
          {[["timeline","Timeline",Layers],["media","Mídia",FolderOpen],["audio","Áudio IA",AudioLines],["effects","Efeitos",Sparkles]].map(([id,label,Icon]: any) =>
            <button key={id} className={`nav-item ${activeTab===id?"active":""}`} onClick={() => setActiveTab(id)}><Icon size={17}/>{label}</button>)}
        </nav>
        {activeTab === "audio" ? <div className="tool-content">
          <div className="section-label">SEPARADOR INTELIGENTE</div>
          <div className="ai-card"><div className="ai-icon"><AudioLines size={22}/></div><strong>Separação de áudio</strong><p>Separe vozes, acompanhamento musical ou diálogo e ambiente de vídeos.</p></div>
          <label className="field-label">TIPO DE MATERIAL</label>
          <select value={sepMode} onChange={e=>setSepMode(e.target.value)} className="select">
            <option value="music">Música: voz + instrumental</option>
            <option value="video">Vídeo: diálogo + fundo</option>
          </select>
          <button className="primary wide" onClick={simulateSeparation} disabled={isSeparating}><Sparkles size={16}/>{isSeparating?"Preparando…":"Separar faixas"}</button>
          <p className="hint">A integração com o modelo de IA ainda não está ativa. Não é gerado áudio separado nesta versão.</p>
        </div> : activeTab === "effects" ? <div className="tool-content">
          <div className="section-label">ADICIONAR CAMADA</div>
          <button className="library-item" onClick={() => addClip("text","Novo texto",3000)}><span className="asset-icon text"><span>T</span></span><span><b>Texto / legenda</b><small>Adicionar uma camada de texto</small></span><Plus size={15}/></button>
          <button className="library-item" onClick={() => addClip("effect","Novo efeito",4000)}><span className="asset-icon effect"><Sparkles size={18}/></span><span><b>Efeito</b><small>Camada de efeito placeholder</small></span><Plus size={15}/></button>
        </div> : <div className="tool-content">
          <div className="section-label">BIBLIOTECA DE PROJETO</div>
          <button className="import-card" onClick={importButton}><div className="import-icon"><Plus size={21}/></div><b>Importar mídia</b><span>Vídeo, áudio ou imagem</span></button>
          <div className="section-label templates-heading">TEMPLATES DE IMAGEM</div>
          <div className="template-grid">
            <button className={`template-tile template-neon ${templateName==="Neon"?"chosen":""}`} onClick={() => applyTemplate("Neon","#25213f")}><span>N</span><small>Neon</small></button>
            <button className={`template-tile template-clean ${templateName==="Branco"?"chosen":""}`} onClick={() => applyTemplate("Branco","#ffffff")}><span>Aa</span><small>Branco</small></button>
            <button className={`template-tile template-dark ${templateName==="Preto"?"chosen":""}`} onClick={() => applyTemplate("Preto","#000000")}><span>Aa</span><small>Preto</small></button>
            <button className={`template-tile template-sunset ${templateName==="Pôr do sol"?"chosen":""}`} onClick={() => applyTemplate("Pôr do sol","#9a4d67")}><span>✦</span><small>Pôr do sol</small></button>
          </div>
          <label className="field-label color-label">COR DO FUNDO</label>
          <div className="color-controls">
            <button className="color-swatch white" aria-label="Fundo branco" onClick={() => applyTemplate("Branco","#ffffff")}/>
            <button className="color-swatch black" aria-label="Fundo preto" onClick={() => applyTemplate("Preto","#000000")}/>
            <input aria-label="Escolher cor personalizada" type="color" value={canvasColor} onChange={e => { setCanvasColor(e.target.value); setPreviewAssetUrl(null); setTemplateName("Personalizado"); }} />
            <span>{canvasColor.toUpperCase()}</span>
          </div>
          <div className="asset-list">
            <button className="library-item" onClick={() => addClip("video","Novo clipe de vídeo")}><span className="asset-icon video"><FileVideo size={17}/></span><span><b>Clipe de vídeo</b><small>Adicionar placeholder</small></span><Plus size={15}/></button>
            <button className="library-item" onClick={() => addClip("audio","Nova faixa de áudio")}><span className="asset-icon audio"><FileAudio size={17}/></span><span><b>Faixa de áudio</b><small>Música ou narração</small></span><Plus size={15}/></button>
            <button className="library-item" onClick={() => addClip("text","Novo título",3000)}><span className="asset-icon text"><FileImage size={17}/></span><span><b>Título</b><small>Camada de texto</small></span><Plus size={15}/></button>
          </div>
          <div className="storage-note"><span className="status-dot"/> Projeto de demonstração local</div>
        </div>}
      </aside>

      <section className="center-panel">
        <div className="preview-top"><span>VISUALIZAÇÃO</span><span className="preview-resolution">PRÉVIA • 16:9</span></div>
        <div className="preview-stage">
          <div className="preview-canvas" style={{background: canvasColor, color: (canvasColor.toLowerCase()==="#ffffff" || canvasColor.toLowerCase()==="#fefefe") ? "#171722" : "#ffffff"}}>
            {!previewAssetUrl && <><div className="preview-glow"/><div className="preview-grid"/></>}
            {previewAssetUrl ? <img className="preview-media" src={previewAssetUrl} alt="Mídia importada para o preview" /> :
              <div className="preview-copy"><span className="preview-eyebrow">NEXUS STUDIO • {templateName.toUpperCase()}</span><h1>{selected?.kind==="text" ? selected.name : "Sua próxima história."}</h1><p>Transforme ideias em movimento.</p></div>}
            <div className="preview-timecode">{currentTime} / {fmt(project.duration)}</div>
          </div>
        </div>
        <div className="transport">
          <div className="transport-left"><button className="icon-btn" onClick={()=>setPlayhead(0)} title="Voltar ao início">|◀</button><button className="play-btn" onClick={togglePlay}>{playing?<Pause size={18} fill="currentColor"/>:<Play size={18} fill="currentColor"/>}</button><button className="icon-btn" onClick={()=>setPlayhead(Math.min(project.duration,playhead+5000))} title="Avançar 5 segundos">▶|</button></div>
          <div className="time-display">{currentTime}</div>
          <div className="transport-right"><button className="icon-btn" onClick={()=>setZoom(Math.max(20,pixelsPerSecond-10))}><ZoomOut size={17}/></button><span>{pixelsPerSecond}px/s</span><button className="icon-btn" onClick={()=>setZoom(Math.min(150,pixelsPerSecond+10))}><ZoomIn size={17}/></button></div>
        </div>
        <div className="timeline-panel">
          <div className="timeline-toolbar">
            <div className="timeline-title"><Layers size={16}/> TIMELINE <span className="track-count">{project.tracks.length} trilhas</span></div>
            <div className="edit-tools"><button title="Dividir no cursor (S)" onClick={splitSelected} disabled={!selected}><Scissors size={16}/><span>Dividir</span></button><button title="Excluir clipe (Delete)" onClick={removeSelected} disabled={!selected}><Trash2 size={15}/></button><button title="Adicionar áudio" onClick={()=>addClip("audio","Nova faixa",5000)}><Plus size={16}/></button></div>
          </div>
          <div className="timeline-scroll" ref={timelineRef} onClick={timelineClick}>
            <div className="timeline-inner" style={{width:totalWidth}}>
              <div className="ruler"><div className="track-label-spacer"/> <div className="ruler-track">{Array.from({length:Math.ceil(project.duration/1000)+1},(_,i)=><div key={i} className="ruler-tick" style={{left:i*1000*px}}><span>{i}s</span></div>)}</div></div>
              {project.tracks.map((track:Track) => <div className="track-row" key={track.id}>
                <div className="track-label"><span className={`track-type ${track.kind}`}>{track.kind==="video"?<Film size={15}/>:track.kind==="audio"?<Music2 size={15}/>:track.kind==="text"?<span>T</span>:<Sparkles size={15}/>}</span><span>{track.name}</span><button title="Silenciar/ocultar trilha" onClick={e=>{e.stopPropagation();}} className="track-menu">•••</button></div>
                <div className="track-lane" style={{width:totalWidth-145}} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault(); if(dragClip){const rect=e.currentTarget.getBoundingClientRect(); move(dragClip,track.id,Math.max(0,(e.clientX-rect.left+e.currentTarget.scrollLeft)/px));setDragClip(null);}}}>
                  {track.clips.map(clip => <div key={clip.id} draggable className={`clip ${selectedId===clip.id?"selected":""} ${clip.kind}`} style={{left:clip.start*px,width:Math.max(22,clip.duration*px),background:clip.color}} onClick={e=>{e.stopPropagation();select(clip.id);}} onDragStart={()=>setDragClip(clip.id)} onDoubleClick={()=>select(clip.id)} title={`${clip.name} • ${fmt(clip.duration)}`}>
                    <div className="trim-handle left" onPointerDown={e=>beginTrim(e,clip,"start")}/><div className="clip-content">{clip.kind==="audio"&&<AudioLines size={13}/>}<span>{clip.name}</span>{clip.kind==="audio"&&<div className="waveform">{Array.from({length:Math.max(8,Math.floor(clip.duration/220))},(_,i)=><i key={i} style={{height:`${15+Math.abs(Math.sin(i*2.17))*70}%`}}/>)}</div>}</div><div className="trim-handle right" onPointerDown={e=>beginTrim(e,clip,"end")}/>
                  </div>)}
                </div>
              </div>)}
              <div className="playhead" style={{left:145+playhead*px}}><div className="playhead-cap"/><div className="playhead-line"/></div>
            </div>
          </div>
          <div className="timeline-footer"><span>{importMessage}</span><span>Snap: 250 ms</span></div>
        </div>
      </section>

      <aside className="right-panel">
        <div className="panel-heading"><span>PROPRIEDADES</span><Settings2 size={15}/></div>
        {selected ? <div className="properties">
          <div className="selected-preview" style={{background:selected.color}}><div className="selected-preview-icon">{selected.kind==="audio"?<AudioLines/>:selected.kind==="text"?<span className="big-t">T</span>:<Film/>}</div><div><strong>{selected.name}</strong><small>{kindLabel(selected.kind)} • selecionado</small></div></div>
          <label className="field-label">NOME DO CLIPE</label><div className="property-value">{selected.name}</div>
          <div className="property-grid"><div><label className="field-label">INÍCIO</label><div className="property-value">{fmt(selected.start)}</div></div><div><label className="field-label">DURAÇÃO</label><div className="property-value">{fmt(selected.duration)}</div></div></div>
          <label className="field-label">POSIÇÃO NA TIMELINE</label><input className="range" type="range" min={0} max={Math.max(project.duration,selected.start+selected.duration)} step={250} value={selected.start} onChange={e=>move(selected.id,currentTrack?.id||project.tracks[0].id,Number(e.target.value))}/>
          <label className="field-label">OPACIDADE (PRÓXIMA ETAPA)</label><div className="disabled-control"><span>100%</span><span>Em breve</span></div>
          <div className="property-divider"/>
          <button className="danger-btn" onClick={removeSelected}><Trash2 size={15}/> Remover clipe</button>
        </div> : <div className="empty-properties"><Settings2 size={28}/><b>Nenhum clipe selecionado</b><span>Selecione um clipe na timeline para ver suas propriedades.</span></div>}
        <div className="keyboard-help"><b>ATALHOS</b><div><kbd>Espaço</kbd><span>Reproduzir / pausar</span></div><div><kbd>S</kbd><span>Dividir no cursor</span></div><div><kbd>Del</kbd><span>Excluir clipe</span></div><div><kbd>Ctrl Z</kbd><span>Desfazer</span></div></div>
      </aside>
    </main>
    <input ref={fileRef} hidden type="file" accept="video/*,audio/*,image/*" onChange={e=>onImport(e.target.files)}/>
    <footer className="statusbar"><span><i className="status-dot"/> Pronto</span><span>Projeto local • Motor de timeline 0.1</span><span>Android + Web</span></footer>
  </div>;
}
