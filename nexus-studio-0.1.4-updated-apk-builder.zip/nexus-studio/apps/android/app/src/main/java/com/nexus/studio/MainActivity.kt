package com.nexus.studio

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.content.Intent
import android.widget.TextView
import android.widget.LinearLayout
import android.view.Gravity
import android.graphics.Color

/**
 * Android host for the shared TypeScript editor.
 * Build the web app and copy apps/web/dist/* to app/src/main/assets/.
 * The JS timeline engine then runs in the WebView on Android as well as desktop/mobile web.
 */
class MainActivity : Activity() {
    private var fileCallback: ValueCallback<Array<android.net.Uri>>? = null
    private val fileChooserRequest = 1007

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequest) {
            val result = if (resultCode == Activity.RESULT_OK && data != null) {
                val uris = data.clipData?.let { clip ->
                    Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                } ?: data.data?.let { arrayOf(it) }
                uris
            } else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 17, 22))
        }
        val banner = TextView(this).apply {
            text = "NEXUS STUDIO  •  ANDROID"
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(21, 22, 29))
        }
        val webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(16, 17, 22))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    callback: ValueCallback<Array<android.net.Uri>>?,
                    params: FileChooserParams?
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*", "audio/*"))
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                    }
                    startActivityForResult(Intent.createChooser(intent, "Escolher mídia"), fileChooserRequest)
                    return true
                }
            }
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(banner, LinearLayout.LayoutParams(-1, -2))
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
}
