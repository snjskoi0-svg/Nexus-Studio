# Nexus Studio 0.1

Base inicial do editor de vídeo Android + Web com motor de timeline compartilhado em TypeScript.

## Requisitos
- Node.js 20 ou superior
- npm 10 ou superior
- Android Studio (para a etapa nativa Android; a casca nativa será adicionada numa etapa posterior)

## Executar a versão Web
Na raiz do projeto:

```bash
npm install
npm run dev
```

Abra a URL local mostrada pelo Vite. Para testar no celular na mesma rede Wi-Fi, use o endereço de rede informado pelo Vite; permita conexões locais no firewall.

## Build e testes
```bash
npm test
npm run build
```

## Funcionalidades já implementadas
- Timeline com trilhas de vídeo, áudio e texto
- Seleção de clipes
- Arrastar clipes entre trilhas compatíveis
- Snap em intervalos de 250 ms
- Divisão no cursor (`S`)
- Trim das extremidades do clipe
- Exclusão (`Delete` / `Backspace`)
- Zoom da timeline
- Play/pause e scrubbing básico
- Histórico undo/redo (`Ctrl+Z`, `Ctrl+Shift+Z`)
- Inclusão de clipes placeholder
- Layout responsivo com controles para celular

## Limitações honestas da versão 0.1
- A importação cria um clipe placeholder de 5 segundos; ainda não decodifica a mídia nem mostra o vídeo/áudio importado no preview.
- O botão de reprodução movimenta o cursor; sincronização com áudio/vídeo real ainda não está conectada.
- Separação por IA ainda não está integrada a um modelo; a interface só prepara o fluxo.
- Exportação MP4, filtros e keyframes ainda não estão implementados.
- O cliente Android nativo e a ponte de execução do motor TypeScript ainda precisam ser construídos. Esta versão valida primeiro o motor e a UX compartilhados na Web.
- O undo/redo está implementado para operações do editor, mas movimentos de trim por pointer ainda geram snapshots durante o arrasto; isso será consolidado em uma única operação na próxima etapa.

## Próximas etapas
1. Persistência do projeto e histórico transacional.
2. Importação real com metadados e preview de mídia.
3. Casca Android em Kotlin/Compose e ponte para o motor compartilhado.
4. Worker de separação musical (ex. Demucs) e modelo específico para diálogo/ruído.
5. Exportação com WebCodecs/FFmpeg.wasm no navegador e Media3/MediaCodec no Android.


## Android host (starter)
A minimal Kotlin Android WebView host is in `apps/android`. It loads the same compiled web app, so the TypeScript timeline engine is shared. After running `npm run build`, copy the contents of `apps/web/dist/` into `apps/android/app/src/main/assets/` (create the `assets` directory first), then open `apps/android` in Android Studio and run the `app` configuration on a device/emulator. This is a starter wrapper, not yet a native Compose editor. Native media codecs and Android audio-separation inference will be integrated behind platform adapters in later stages.


## Atualização 0.1.1: imagens e cores
- Importação de imagens com pré-visualização local via URL de objeto.
- Templates rápidos de preview: Neon, Branco, Preto e Pôr do sol.
- Seletor de cor personalizada para o fundo.
- WebView Android com seletor de arquivos para imagens, vídeos e áudio.
- Importação ainda não adiciona a imagem como mídia persistente nem faz render/export real; o preview é local à sessão.

## Gerar o APK pela nuvem do GitHub (versão 0.1.4)

O workflow `.github/workflows/build-android.yml` automatiza testes do motor de timeline, build da interface web, empacotamento dos recursos na WebView Android, compilação e verificação do APK. Ele gera um APK **debug para testes**, não assinado para publicação na Play Store.

### Usando o pacote ZIP pelo celular

1. Envie `nexus-studio-0.1.4-updated-apk-builder.zip` para a raiz do seu repositório GitHub.
2. Crie/edite `.github/workflows/build-android.yml` no repositório e cole o conteúdo do arquivo `nexus-studio-build-0.1.4.yml` fornecido junto com o pacote.
3. Abra **Actions** → **Nexus Studio 0.1.4 — Android APK Builder** → **Run workflow**.
4. Quando a execução terminar, baixe o artefato `nexus-studio-0.1.4-android-apk`. Ele contém `Nexus-Studio-0.1.4-debug.apk` e `SHA256SUMS.txt`.

Se enviar os arquivos do projeto já extraídos para o repositório, inclua também `.github/workflows/build-android.yml` e execute o workflow normalmente. Não é necessário colocar um ZIP dentro do projeto já extraído.

### Limitações funcionais

Esta atualização melhora a preparação e compilação do APK, mas não transforma automaticamente as funções demonstrativas em um editor de vídeo completo. A timeline e a interface são um protótipo; sincronização real de áudio/vídeo, exportação MP4 e separação de áudio por IA ainda não estão implementadas. O APK só estará disponível depois que o GitHub Actions concluir a compilação com sucesso.
