# Audio separation service (planned)

Dois pipelines independentes serão mantidos:

1. **Música:** separação de vocais/instrumental e, opcionalmente, stems (bateria, baixo, outros).
2. **Vídeo/fala:** isolamento de fala com supressão/separação de ambiente, usando modelo específico para diálogo.

Não ativar um endpoint de produção até escolher modelo, licença, requisitos de GPU/CPU, limites de upload, política de retenção e proteção de dados. Preferir execução local quando o modelo e o hardware suportarem. Não simular uma separação real no frontend.
